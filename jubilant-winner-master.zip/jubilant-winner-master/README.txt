README

This is a readme document for the description of our project.

Game:
Hearts
